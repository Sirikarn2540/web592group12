<style>
.btn-default{
	background:rgba(1,1,1,0.5);
	color:#FFF;	
}
.btn-default:hover{
	background:rgba(1,1,1,0.6);
	color:#FFF;	
}
</style>
<?php
  include_once("config.php");
  $phpfile="body_$page.php";
  if(file_exists($phpfile)){
    include($phpfile);
  
  }
  else{
     echo "ไม่พบไฟล์  $phpfile ";
  }  
 
?>  