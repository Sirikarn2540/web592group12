<style>
#footer{
	background-color:rgba(233,233,232,0.8);
	font-size:22px;
	color:#000;
	text-align:right;
}
</style>
<div class="col-xs-12" id='footer'>
<font face="DilleniaUPC">
<br>
เว็บไซต์นี้เป็นส่วนหนึ่งของการเรียนวิชา 322-236  
Wep Application Programming.
<br>
</font>
</div>
