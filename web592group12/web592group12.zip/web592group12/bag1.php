<!doctype html>
<html lang="en">
<head>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BAGS</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
<style>
  .modal-header, h5, .close {
      background-color:Gray;
      color:white !important;
      text-align: center;
      font-size: 30px;
  }
  </style>
</head>
<body>

								<div id="01" class= "modal fade" >
									<div class="modal-dialog modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal">&times;</button>
											<h5 class="modal-title">ADIDAS CLASSIC TRICOT</h5>
											</div>
										<div class="modal-body">
										<center>
												<div id="myCarousel01" class="carousel slide" data-ride="carousel">
												<ol class="carousel-indicators">
													<li data-target="#myCarousel01" data-slide-to="0" class="active"></li>
											
												</ol>
												<div class="carousel-inner" role="listbox">
													<div class="item active">
													<img src="http://d12vfgykacfet6.cloudfront.net/tmp/catalog/product/large/BK7156_Fout_Model_eCom.jpg" alt="Chania">
													</div>
												</div>
												<a class="left carousel-control" href="#myCarousel01" role="button" data-slide="prev">
													<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
													<span class="sr-only">Previous</span>
												</a>
												<a class="right carousel-control" href="#myCarousel01" role="button" data-slide="next">
													<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
													<span class="sr-only">Next</span>
												</a>
												</div>
												<br>
													<p>Type : Bags</p>
													<p>Brand : Adidas</p>
													<p>Price : 1,690 Bath</p>
													<p>Color : Black</p>
										</center>
										<div class="modal-footer">
										<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
										</div>
										</div>    
									</div>
									</div>
								</div>
								</body>
								</html >