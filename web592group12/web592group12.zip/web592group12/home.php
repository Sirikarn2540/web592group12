<!doctype html>
 <?php error_reporting(0);
 include_once("config.php");
 //$appid = "web592group12.appspot.com";
 //$page = $_GET['p'];
 //if($page=='') $page='KIDPAP';
 //$title = $page;
?>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <meta name="viewport" content="width=device-width, initial-scale=1.0" />
 <title><?= $page ?> </title>
	<link rel="icon" href="https://image.flaticon.com/icons/png/128/252/252037.png">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	
	<link rel="stylesheet"href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
	
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/navbar-fixed-top.css" rel="stylesheet">

    <script src="js/ie-emulation-modes-warning.js"></script>
</head>

<style>
body {
background-color:rgb(253,254,230,0.8);
background-attachment:fixed;
background-repeat: no-repeat; 
background-size: cover;}
.container{
	width:auto;
}
.navbar-default {
	backgroud-color:rgba(255,255,255,0.8);

	width:100%;
}
.navbar-brand{
	font-face:Arial;
	font-size:45px;
	font-color:#FFF;
}
.navbar-right{
	font-size:20px;
}
</style>

<body>
 <nav class="navbar navbar-default"> 
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
		  <br>
          <a class="navbar-brand" href="#"><b>KIDPAP SHOP</b></a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
		 <?php 
		   include_once("pro_menu.php");
		 ?> 
		<ul class="nav navbar-nav navbar-right">
		 <li><a href="pro_contact.php">contact</a>
		</ul>
        </div>
	  </div>	
	  <br>
    </nav>
	

	<center><img src="cap2.jpg" width="97%" ></center>	
	<br>
	
    <div class="container">
<?php
   include_once("pro_body.php");  
?>
    </div>
	<br>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<footer class="text-center page-footer">
<div id="footer">
<?php include("pro_footer.php");?>
</div>
</footer>
</body>
</html>