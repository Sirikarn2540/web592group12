<style>
.btn-default{
	background-color:rgb(201, 203, 175);
	color:#FFF;
	border:1px;
	solic:#000;
}
</style>
<?php
 use google\appengine\api\users\User;
 use google\appengine\api\users\UserService;
 use google\appengine\api\cloud_storage\CloudStorageTools;
 
 include_once("config.php");  
 global $appid,$db;  
 $gid=$_GET['g'];
 $pid=$_GET['i'];  
 if(isset($db['items'][$gid][$pid])){
   $grec=$db['groups'][$gid];
    $prec=$db['items'][$gid][$pid];   
  }else{
   echo "ข้อมูลไม่ถูกต้อง";
   return;
 }
 
 echo "<center><h1 font-face='Angsananew' > Product ID : $pid<br>$prec[name] </h1></center> ";
 if(isset($prec['picfile']) && file_exists($prec['picfile'])){
   $img=CloudStorageTools::getImageServingUrl($prec['picfile'],["size"=>250]);   
   echo "<center><img src='$img'></center><br>";
 }
?>

<?php
echo "<center>";
print_r($prec[detail]);
echo "<br>";
echo"Price : ";
print_r($prec[price]);

echo "</center>";

?>