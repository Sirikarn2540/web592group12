<?php
 $gid=$_GET['g'];
 use google\appengine\api\users\UserService;
  use google\appengine\api\cloud_storage\CloudStorageTools;
 if(!isset($db['groups'][$gid])){
   echo "ไม่พบข้อมูลกลุ่มสินค้า";
   return;
 } 
 $grec = $db['groups'][$gid];
 $list = [];
 if(isset($db['items'][$gid]))$list=$db['items'][$gid];
 
 echo "
 
 <h1><center> $grec[name] </center></h1><br>
 
 ";
 
 foreach($list as $pid=>$prec){
	 $imgtag="";
	 $edit="";
	 if(isset($prec['picfile']) && file_exists($prec['picfile'])){
     $img=CloudStorageTools::getImageServingUrl($prec['picfile'],["size"=>150]);   
     $imgtag="<img src='$img'>";
     }
	 if(UserService::isCurrentUserAdmin()){
      $edit= "<a href='home.php?p=additem&g=$gid&i=$pid'>Edit</a>";
   }
   echo "<div class='col-xs-12 text-center col-sm-3'>
                        <div class='thumbnail product-box'>
						<h3><b>$prec[name]</b></h3>
						$imgtag
						<h5>Price: $prec[price]</h5>
						<a href='home.php?p=detail&g=$gid&i=$pid'>Detail</a>&nbsp;
						$edit<br>
						
						</div>
						</div>
						";
   
 }

 if(UserService::isCurrentUserAdmin()){
    echo "<a href='home.php?p=additem&g=$gid' class='glyphicon glyphicon-plus' aria-hidden='true'></a>";
 }
 ?>