<style>
.dropdown-menu{
	font-family:Angsananew;
}
</style>

<li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Admin <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li class="dropdown-header"><h5>สำหรับผู้ดูแลระบบ</h5></li>
                <li><a href="home.php?p=editgroup">Edit Groups</a></li>
              </ul>
            </li>