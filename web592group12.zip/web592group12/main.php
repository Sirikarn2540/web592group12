<!-- Top Left -->
<html lang="en">
<head>
 <meta charset="UTF-8">
 <title>KIDPAP</title>
	<link rel="icon" href="https://image.flaticon.com/icons/png/128/252/252037.png">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<link rel="stylesheet"href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
	
</head>

<style>
body {
background-image: url("bgm.jpg");
background-attachment:fixed;
background-repeat: no-repeat; 
background-size: cover;}
#head{
	background-color:rgba(1, 1, 1, 0.7);
	font-face:Arial;
	font-size:90px;
}
button.buttons{
	background-color:rgba(1, 1, 1, 0.7);
	border: 2px solid #FFF;
	font-face:Arial;
	font-size:50px;
	color:#FFF;
}
#head button:hover{
	background-color: #FFF;
	color:#000;
	border: 2px solid #000;
}
</style>
	<br>
	<br>
	<br>
	<br>
	<br>
	
	<div class="col-xs-12" id="head"  >
	<br>
	<center>
	<font color="#FFF"><b> Welcome To KIDPAP Shop </b></font>
	</center><br>
	<center><a href="home.php"><button class='buttons'  onclick="home" >Go To Site</button></a></center>
	<br>
	</div>
	<br>
	<br>
	<br>
	<br>
	

						