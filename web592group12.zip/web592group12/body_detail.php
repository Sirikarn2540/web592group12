<style>
.btn-default{
	background-color:rgb(201, 203, 175);
	color:#FFF;
	border:1px;
	solic:#000;
}
</style>
<?php
 use google\appengine\api\users\User;
 use google\appengine\api\users\UserService;
 use google\appengine\api\cloud_storage\CloudStorageTools;
 
 include_once("config.php");  
 global $appid,$db;  
 $gid=$_GET['g'];
 $pid=$_GET['i'];  
 if(isset($db['items'][$gid][$pid])){
   $grec=$db['groups'][$gid];
    $prec=$db['items'][$gid][$pid];   
  }else{
   echo "ข้อมูลไม่ถูกต้อง";
   return;
 }
 
  echo "<div class='col-xs-12 text-center col-sm-12' >
		 <div class='thumbnail product-box'> ";
  echo " <center><h1 font-face='Angsananew' ><b> $prec[name] </b></h1> 
        <h3 font-face='Angsananew' > Product ID : $pid </h3><br></center> ";
 if(isset($prec['picfile']) && file_exists($prec['picfile'])){
   $img=CloudStorageTools::getImageServingUrl($prec['picfile']);   
   echo "<center><img src='$img' width='250' height='300'></center><br>";  
 }
echo "<center>";
echo "<h3 font-face='Angsananew'>";
echo"<b>Price : </b>";
print_r($prec[price]);
echo "<br>";
echo "<b>Brand : </b>";
print_r($prec[brand]);
echo "<br>";
echo "<b>Color :</b>";
print_r($prec[color]);
echo "<br><br>";
echo "<b>Detail</b><br>";
print_r($prec[detail]);
echo "<br>";
echo "</h3>";
echo "</center>";

echo "</div>";
echo "</div>";

echo "<br><br>";
echo "<br><br>";
echo "<br><br>";
echo "<br><br>";
echo "<br><br>";
echo "<br><br>";
echo "<br><br>";
echo "<br><br>";
echo "<br><br>";
echo "<br><br>";
echo "<br><br>";
echo "<br><br>";
echo "<br><br>";
echo "<br><br>";
echo "<br><br>";
echo "<br><br>";
echo "<br><br>";
echo "<br><br>";
echo "<br><br>";
echo "<br><br>";
echo "<br><br>";



?>