<style>
.dropdown-menu{
	font-family:Arial;
}
</style>
<li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
			  <img src="person.png">&nbsp;&nbsp;Admin<span class="caret"></span></a>
              <ul class="dropdown-menu">  
                <li><a href="home.php?p=editgroup">Edit Groups</a></li>
              </ul>
            </li>