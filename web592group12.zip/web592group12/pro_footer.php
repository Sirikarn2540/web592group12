<style>
#footer{
	background-color:rgba(0,0,0,1.0);
	font-size:20px;
	color:#FFF;
	text-align:right;
	
}
</style>
<div class="col-sm-12 col-xs-12"  id='footer'>
<font face="DilleniaUPC">
<br>
เว็บไซต์นี้เป็นส่วนหนึ่งของการเรียนวิชา 322-236  
Wep Application Programming.
<br>
</font>
</div>
