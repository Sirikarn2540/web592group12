<html lang="en">
<head>
 <meta charset="UTF-8">
 <title>KIDPAP</title>	
 <meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link rel="icon" href="https://image.flaticon.com/icons/png/128/252/252037.png">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<link rel="stylesheet"href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
</head>
<style>
body {
background-color:rgba(255,255,255,1.0);
background-attachment:fixed;
background-repeat: no-repeat; 
background-size: cover;
}
.navbar-inverse {
	background-color:rgba(0,0,0,1.0);
	width:100%;
}
.navbar-brand{
	font-face:Arial;
	font-size:45px;
	color:#FFF;
}
</style>
<body role="document">
<nav class="navbar navbar-inverse" role="navigation">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">  
				<br>
                <a class="navbar-brand" href="#"><strong>CONTACT</strong></a>  
            </div>
			<br>
			<ul class="nav navbar-nav navbar-right">
		 <li><a href="home.php"><img src="hm32.png"></a>
		</ul>
		</div>
		<br>
</nav>
<br>
<br>
<br>
<br>



<center>         
  <a href="https://www.facebook.com/pornpan.sitthinan">
  <img src="miam.png" class="img-circle" alt="Cinque Terre" width="270" height="270"></a>
  <font face="Arial"><h2><font color="#000"><b>MiamMiem</b></h2>
  <p>Miss.Pornpan Sitthinan <br>583021142-7</p></font></font>
  <br>
  <a href="https://www.facebook.com/sirikarn.polkome.3">       
  <img src="yok.png" class="img-circle" alt="Cinque Terre" width="270" height="270"></a> 
  <h2><font face="Arial"><font color="#000"><b>YokYok</b></h2>
  <p>Miss.Sirikarn Polkome <br>583020417-9</p></font></font>     
  <br>
  <a href="https://www.facebook.com/jo.aounnoi">
  <img src="som.png" class="img-circle" alt="Cinque Terre" width="270" height="270"></a> 
  <h2><font face="Arial"><font color="#000"><b>Som-O</b></h2>
  <p>Miss.Jatuporn Datui <br>583020380-6</p></font></font> 
  <br>
  <a href="https://www.facebook.com/profile.php?id=100004826719062">
  <img src="https://www.img.in.th/images/74225e556700793c8681261aa5bc0486.png" width="270" height="270"></a>
  <font face="Arial"><h2><font color="#000"><b>Jester</b></h2>
  <p>Mr.chakri kunsing <br>583020381-4</p></font></font>  
  <br>
  <a href="https://www.facebook.com/zynezenz.za?fref=ts">
  <img src="zye.png" class="img-circle" alt="Cinque Terre" width="270" height="270" ></a> 
  <h2><font face="Arial"><font color="#000"><b>ZyneZyne</b></h2>
  <p>Miss.Nattarika Kuldilok <br>583021132-0</p></font></font> 
  <br>
</center>
<footer class="text-center page-footer">
<div id="footer"><?php include("pro_footer.php");?></div>
</footer>
</body>
</html>