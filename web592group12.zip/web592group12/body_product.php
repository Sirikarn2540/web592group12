<style>

.headd{
	background-color:#000;
	width:60%;
	font-face:arial;
	color:#FFF;
	font-size:40pt;
	
}
#tail{
	font-size:14pt;
}
</style>


<?php
 $gid=$_GET['g'];
 use google\appengine\api\users\UserService;
  use google\appengine\api\cloud_storage\CloudStorageTools;
 if(!isset($db['groups'][$gid])){
   echo "ไม่พบข้อมูลกลุ่มสินค้า";
   return;
 } 
 $grec = $db['groups'][$gid];
 $list = [];
 if(isset($db['items'][$gid]))$list=$db['items'][$gid];
 
 echo "<br><br>
 
 <center><div class='headd'> $grec[name] </div></center><br>
 
 ";
 
 foreach($list as $pid=>$prec){
	 $imgtag="";
	 $edit="";
	 if(isset($prec['picfile']) && file_exists($prec['picfile'])){
     $img=CloudStorageTools::getImageServingUrl($prec['picfile'],["size"=>250]);   
     $imgtag="<img src='$img'>";
     }
	 if(UserService::isCurrentUserAdmin()){
      $edit= "<a href='home.php?p=additem&g=$gid&i=$pid'>Edit</a>";
   }
   echo "<div class='col-xs-12 text-center col-sm-3' id='tail'>
                        <div class='thumbnail product-box'>
						<h3><b>$prec[name]</b></h3><br>
						$imgtag<br>
						<a href='home.php?p=detail&g=$gid&i=$pid'>Detail</a>&nbsp;
						$edit<br>
						
						</div>
						</div>
						";
   
 }

 if(UserService::isCurrentUserAdmin()){
    echo "<center><a href='home.php?p=additem&g=$gid' class='glyphicon glyphicon-plus' aria-hidden='true'></a></center>";
 }
 ?>